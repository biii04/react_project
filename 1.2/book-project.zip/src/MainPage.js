import React from "react";
import { Link } from 'react-router-dom';

const MainPage = () => {
    return(
        <div>
            <h3>메인페이지</h3>

            <ul>
                <li><Link to="/book">Book</Link></li>
                <li><Link to="/blog">Blog</Link></li>
                <li><Link to="/cafe">Cafe</Link></li>
            </ul>
        </div>
    );
};

export default MainPage;
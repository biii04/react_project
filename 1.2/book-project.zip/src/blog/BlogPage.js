import React, { useEffect, useState } from "react";
import { blogSearch } from "../blog-api";
import BlogItem from './BlogItem';
import {Link} from 'react-router-dom';

const BlogPage = props => {
  const [blogs, setBlogs] = useState([]);
  const [text, setText] = useState("");
  const [query, setQuery] = useState('');

  // 블로그 검색
  useEffect(() => {
    if (query.length > 0) {
      blogSearchHttpHandler(query, true);
    }
  }, [query]);

  const onEnter = e => {
    if (e.keyCode === 13) {
      setQuery(text);
    }
  };

  const onTextUpdate = e => {
    setText(e.target.value);
  };
  // blog search 핸들러
  const blogSearchHttpHandler = async (query, reset) => {
    // paramter 설정
    const params = {
      query: query,
      sort: "accuracy", // accuracy | recency 정확도 or 최신
      page: 1, // 페이지번호
      size: 10 // 한 페이지에 보여 질 문서의 개수
    };

    const { data } = await blogSearch(params);  //api 호출
    if (reset) {
      setBlogs(data.documents);
    } else {
      setBlogs(blogs.concat(data.documents));
    }
  };

  return (
    <div className="container">
      <Link to="/main">Main</Link>
      <input
        type="search"
        placeholder="찾고 싶은 블로그를 검색하세요"
        name="query"
        className="input_search"
        onKeyDown={onEnter} // enter
        onChange={onTextUpdate} // change
        value={text || ''} // view
      />

      <ul>
        {blogs.map((blog, index) => (
          <BlogItem
            key={index}
            thumbnail={blog.thumbnail}
            title={blog.title}
            blogname={blog.blogname}
            contents={blog.contents}
            url={blog.url}
          />
        ))}
      </ul>
    </div>
  );
};

export default BlogPage;
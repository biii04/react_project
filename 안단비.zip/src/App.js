import React from "react";
import BookPage from "./book/BookPage";
import BlogPage from "./blog/BlogPage";
import MainPage from "./MainPage";
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import CafePage from "./cafe/CafePage";

function App() {
  return (
  <BrowserRouter>
  <div>
    <Routes>
      <Route path="/" element={<MainPage/>}></Route>
      <Route path="/book" element={<BookPage/>}></Route>
      <Route path="/blog" element={<BlogPage/>}></Route>
      <Route path="/cafe" element={<CafePage/>}></Route>
    </Routes>
  </div>
  </BrowserRouter>
  );
};

export default App;
import axios from 'axios';

export const Kakao = axios.create({
  baseURL: 'https://dapi.kakao.com', 
  headers: {
    Authorization: `KakaoAK 8c4dcb3073f637d44b10e1d408bcff94`,
  },
});

export const cafeSearch = (params) => {
  return Kakao.get('/v2/search/cafe?target=title', { params });
};

export const cafe = () => {
  return Kakao.get('/v2/search/cafe?target=title');
};
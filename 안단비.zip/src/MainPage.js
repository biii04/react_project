import React from "react";
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import {BiBook} from 'react-icons/bi'
import {BsFillPeopleFill} from 'react-icons/bs';
import {RiCommunityLine} from 'react-icons/ri';

const StyledLink = styled(Link)`
	box-sizing: border-box;
	display: block;
	padding: 4px 8px;
	margin: 0 auto;
	text-align: center;
    text-decoration: none;
    size: 16px;
`;

const MainPageBlock = styled.div`
    box-sizing: border-box;
    padding-bottom: 5rem;
    padding-top: 2rem;
    width: 768px;
    margin: 0 auto;
    margin-top: 2rem;
    text-align: center;
    li{
        width: 800px;
    }
`;

const MainPage = () => {
    return(
        <MainPageBlock>
            <h2>[카카오 api를 활용한 책, 블로그, 카페 검색]</h2>
                <br/><br/>
                <li><StyledLink to="/book"><BiBook color="brown"/> Book</StyledLink></li><br/><br/>
                <li><StyledLink to="/blog"><BsFillPeopleFill color="silver"/> Blog</StyledLink></li><br/><br/>
                <li><StyledLink to="/cafe"><RiCommunityLine color="orange"/> Cafe</StyledLink></li>

        </MainPageBlock>
    );
};

export default MainPage;
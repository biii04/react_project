import React from 'react';
import styled from 'styled-components';

const MovieItemBlock = styled.div`
display: flex;
.contents {
h2 {
margin: 0;
a { color: black; }
}
p {
margin: 0; line-height: 1.5;
margin-top: 0.5rem; white-space: normal;
}
}
& + & { margin-top: 3rem; }
`;

const MovieItem = ({ movie }) => {
    const { rank, rankOldAndNew, movieNm } = movie;
    // console.log(movie)
    return (
      <MovieItemBlock>
        <div className="rank">
          {rank}
          <span>위</span>
          <div className="new">{rankOldAndNew === "OLD" ? "" : rankOldAndNew}</div>
        </div>
        <div className="title">{movieNm}</div>
      </MovieItemBlock>
    );
  };
  
  export default MovieItem;
import { useState } from 'react';
import axios from 'axios';
import MovieList from './components/MovieList';

const App = () => {
  return <MovieList/>;
};

export default App;

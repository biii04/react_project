import axios from 'axios';

export const Kakao = axios.create({
  baseURL: 'https://dapi.kakao.com', // 공통 요청 경로를 지정해준다.
  headers: {
    Authorization: `KakaoAK 8c4dcb3073f637d44b10e1d408bcff94`,
  },
});

// search book api
export const bookSearch = (params) => {
  return Kakao.get('/v3/search/book?target=title', { params });
};

// book api
export const book = () => {
  return Kakao.get('/v3/search/book?target=title');
};
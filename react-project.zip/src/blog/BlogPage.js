import React, { useEffect, useState } from "react";
import { blogSearch } from "../blog-api";
import BlogItem from './BlogItem';
import {Link} from 'react-router-dom';
import '../all.css';
import {AiOutlineHome} from 'react-icons/ai';  
import styled from "styled-components";
import Pagination from "../Pagination";

const StyledLink = styled(Link)`
	box-sizing: border-box;
	display: block;
	padding: 4px 8px;
	margin: 0 auto;
	text-align: center;
  text-decoration: none;
  size: 16px;
`;



const BlogPage = props => {
  const [blogs, setBlogs] = useState([]);
  const [text, setText] = useState("");
  const [query, setQuery] = useState('');
  const [limit, setLimit] = useState(10);
  const [page, setPage] = useState(1);
  const offset = (page - 1) * limit;

  // 블로그 검색
  useEffect(() => {
    if (query.length > 0) {
      blogSearchHttpHandler(query, true);
    }
  }, [query]);

  const onEnter = e => {
    if (e.keyCode === 13) {
      setQuery(text);
    }
  };

  const onTextUpdate = e => {
    setText(e.target.value);
  };
  // blog search 핸들러
  const blogSearchHttpHandler = async (query, reset) => {
    // paramter 설정
    const params = {
      query: query,
      sort: "accuracy", // accuracy | recency 정확도 or 최신
      page: 1, // 페이지번호
      size: 30 // 한 페이지에 보여 질 문서의 개수
    };

    const { data } = await blogSearch(params);  //api 호출
    if (reset) {
      setBlogs(data.documents);
    } else {
      setBlogs(blogs.concat(data.documents));
    }
  };

  // function decodeHTMLEntities (str) {
  //   if(str && typeof str === 'string') {
  //     // strip script/html tags
  //     str = str.replace(/<script[^>]*>([\S\s]*?)<\/script>/gmi, '');
  //     str = str.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gmi, '');
  //     element.innerHTML = str;
  //     str = element.textContent;
  //     element.textContent = '';
  //   }

  //   return str;
  // }

  return (
    <>

    <StyledLink to="/"><AiOutlineHome size="50" color="purple"/> </StyledLink>
    <div className="container1">
      
      <input
        type="search"
        placeholder="궁금한 것을 블로그에 검색해보세요!"
        name="query"
        className="input_search"
        onKeyDown={onEnter} // enter
        onChange={onTextUpdate} // change
        value={text || ''} // view
      />
    </div>
    <br/>
    
    <div className="container4">
    <label>
        페이지 당 표시할 게시물 수&nbsp;:&nbsp;&nbsp;
        <select
          type="number"
          value={limit}
          onChange={({ target: { value } }) => setLimit(Number(value))}
        >
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="40">40</option>
          <option value="50">50</option>
        </select>
      </label>
      </div>
    <div className="container3">
    
      <ul>
      {blogs.slice(offset, offset + limit).map(( blog, index ) => {
        // {blogs.map((blog, index) => {
          console.log(blog);
          const oldText = blog.contents;
           const newText = oldText.replace(/(<([^>]+)>)/ig,"").replace(/&quot;/g,"").replace(/\"n/,"").replace(/&amp;/g,"").replace(/\&#34;/g,"'").replace(/\&#39;/g,"'").replace(/\&lt;/g,"<").replace(/\&gt;/g,">");
           const newTitle = blog.title.replace(/(<([^>]+)>)/ig,"").replace(/&quot;/g,"").replace(/\"n/,"").replace(/&amp;/g,"").replace(/\&#34;/g,"'").replace(/\&#39;/g,"'").replace(/\&lt;/g,"<").replace(/\&gt;/g,">");
          // console.log(newText);
          return(
          <BlogItem
            key={index}
            thumbnail={blog.thumbnail}
            title={newTitle}
            blogname={blog.blogname}
            contents={newText}
            url={blog.url}
          />)
          
          
        })}  
      </ul>
      <Pagination
          total={blogs.length}
          limit={limit}
          page={page}
          setPage={setPage}
        />
    </div>

    </>
  );
};

export default BlogPage;
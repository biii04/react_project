import axios from "axios";

const Kakao = axios.create({
  baseURL: "https://dapi.kakao.com",
  headers: {
    Authorization: "KakaoAK 8c4dcb3073f637d44b10e1d408bcff94"
  }
});

// search blog api
export const blogSearch = params => {
  return Kakao.get("/v2/search/blog?target=title", { params });
};

export const blog = () => {
  return Kakao.get('/v2/search/blog?target=title');
}
import React, { useEffect, useState } from "react";
import { cafeSearch } from "../cafe-api";
import CafeItem from "./CafeItem";
import {Link} from 'react-router-dom';
import {AiOutlineHome} from 'react-icons/ai';
import Pagination from "../Pagination";  
import '../all.css';

import styled from "styled-components";

const StyledLink = styled(Link)`
	box-sizing: border-box;
	display: block;
	padding: 4px 8px;
	margin: 0 auto;
	text-align: center;
  text-decoration: none;
  size: 16px;
`;


const CafePage = props => {
  const [cafes, setCafes] = useState([]);
  const [text, setText] = useState("");
  const [query, setQuery] = useState("");
  const [limit, setLimit] = useState(10);
  const [page, setPage] = useState(1);
  const offset = (page - 1) * limit;

  // 블로그 검색
  useEffect(() => {
    if (query.length > 0) {
      cafeSearchHttpHandler(query, true);
    }
  }, [query]);

  const onEnter = e => {
    if (e.keyCode === 13) {
      setQuery(text);
    }
  };

  const onTextUpdate = e => {
    setText(e.target.value);
  };
  
  // blog search 핸들러
  const cafeSearchHttpHandler = async (query, reset) => {
    // paramter 설정
    const params = {
      query: query,
      sort: "accuracy", // accuracy | recency 정확도 or 최신
      page: 1, // 페이지번호
      size: 30 // 한 페이지에 보여 질 문서의 개수
    };

    const { data } = await cafeSearch(params);  //api 호출
    if (reset) {
      setCafes(data.documents);
    } else {
      setCafes(cafes.concat(data.documents));
    }
  };

  return (
    <>
    <br/>
    <StyledLink to="/"><AiOutlineHome size="50" color="purple"/> </StyledLink><br/>

    <div className="container1">
      
      <input
        type="search"
        placeholder="궁금한 것을 카페에 검색해보세요!"
        name="query"
        className="input_search"
        onKeyDown={onEnter} // enter
        onChange={onTextUpdate} // change
        value={text || ''} // view
      />
    </div>

    <div className="container2">
    <label>
        페이지 당 표시할 게시물 수&nbsp;:&nbsp;&nbsp;
        <select
          type="number"
          value={limit}
          onChange={({ target: { value } }) => setLimit(Number(value))}
        >
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="40">40</option>
          <option value="50">50</option>
        </select>
      </label>
      </div>

    <div className="container3">
      <ul>
        {cafes.slice(offset, offset + limit).map((cafe, index) => {
          console.log(cafe.title);
          const oldTitle = cafe.title;
          const newTitle = oldTitle.replace(/(<([^>]+)>)/ig,"").replace(/&quot;/g,"").replace(/\"n/,"").replace(/&amp;/g,"").replace(/\&#34;/g,"'").replace(/\&#39;/g,"'").replace(/\&lt;/g,"<").replace(/\&gt;/g,">");
          const newContents = cafe.contents.replace(/(<([^>]+)>)/ig,"").replace(/&quot;/g,"").replace(/\"n/,"").replace(/&amp;/g,"").replace(/\&#34;/g,"'").replace(/\&#39;/g,"'").replace(/\&lt;/g,"<").replace(/\&gt;/g,">");
          return(
          <CafeItem
            key={index}
            thumbnail={cafe.thumbnail}
            title={newTitle}
            contents={newContents}
            url={cafe.url}
          />)
        })}
      </ul>
      <Pagination
          total={cafes.length}
          limit={limit}
          page={page}
          setPage={setPage}
        />
    </div>
    </>
  );
};

export default CafePage;
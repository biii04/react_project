import React from "react";
import styled from 'styled-components';
const ItemBlock = styled.div`
display: flex;
a {
  text-decoration: none;
  color: pink;
}

article {
  word-break: break-all;
}
`;

const CafeItem = props => {
  return (

    <ItemBlock>
        <li className="contents">
            <img src={props.thumbnail} alt={props.thumbnail}/><br/>

            <h3>{props.title}</h3><br/>
            <article>{props.contents}</article><br/>
            <a href={props.url}>링크 바로가기</a>
        </li>
    </ItemBlock>
  );
};

export default CafeItem;
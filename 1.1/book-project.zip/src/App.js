import React from "react";
import BookPage from "./components/BookPage";
import {BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';

const App = () => {
  return (
  <BrowserRouter>
  <div>
      <h1>Book Search Site</h1>
      <ul>
        <li><NavLink to="/book">Book</NavLink></li>
      </ul>
    <Routes>
      <Route path="/book" element={<BookPage/>}></Route>
    </Routes>
  </div>
  </BrowserRouter>
  );
};

export default App;